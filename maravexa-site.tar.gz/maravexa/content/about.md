+++
title = "About"
description = "About this site and its author."
+++

## About me

Write a few paragraphs about yourself here. This page is a plain
Markdown file — same as any blog post — so it's easy to keep up to date.

## About this site

This site is built with [Zola](https://www.getzola.org/), a static site
generator written in Rust. It is hosted on
[Cloudflare Pages](https://pages.cloudflare.com/).

The design goals:

- Fast: no trackers, no ads, no unnecessary JavaScript
- Accessible: high-contrast by default, semantic HTML, keyboard navigable
- Readable by humans and AI alike
- Easy to maintain: blog posts are plain Markdown files

The source is available on [GitHub](https://github.com/yourname/maravexa).

## Contact

The best way to reach me is [email@example.com](mailto:email@example.com).
